public class QueueDemo {  
 private static int capacity=10;  
 int queuearray[]=new int[10];  
 int size=0;  
 int top=-1;  
 int rear=0;  
  
public void push(int pushedElement) {  
  if (top<capacity-1) {  
   top++;  
   queuearray[top]=pushedElement;  
  } 
}  
  
public void pop() {  
  if (rear<=top) {  
   rear++;    
  }
}  
  
public void print() {  
  if (top>=rear) {    
   for (int i=rear;i<=top;i++) {  
    System.out.println(queuearray[i]);  
    }  
  }  
}  
  
public static void main(String[] args) {  
  QueueDemo queueDemo=new QueueDemo();   
  queueDemo.push(10);  
  queueDemo.push(20);  
  queueDemo.push(30);  
  queueDemo.push(40);
  System.out.println("pushed elements are : ");
  queueDemo.print();  
  queueDemo.pop();  
  queueDemo.pop();
  System.out.println("poped elements are : ");
  queueDemo.print();  
  }  
}  